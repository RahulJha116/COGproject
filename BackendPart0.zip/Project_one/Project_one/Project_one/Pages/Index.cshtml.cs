﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project_one.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
