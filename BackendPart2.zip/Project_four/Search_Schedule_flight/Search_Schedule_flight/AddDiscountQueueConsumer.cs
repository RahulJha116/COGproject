﻿using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Search_Schedule_flight.DbContexts;
using Search_Schedule_flight.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Search_Schedule_flight
{
    public class AddDiscountQueueConsumer
    {

        ConnectionFactory factory { get; set; }
        IConnection connection { get; set; }
        IModel channel { get; set; }
        public void Consume()
        {

            channel.QueueDeclare("AddDiscountQueue",
                durable: true,
                exclusive: false,
                autoDelete: false,
                arguments: null);

            var consumer = new EventingBasicConsumer(channel);

            consumer.Received += (Sender, e) =>
            {

                var body = e.Body.ToArray();
                var message = Encoding.UTF8.GetString(body);

                var discount = new Discount();
                Task.Run(() =>
                {
                    var chunks = message.Split("|");
                    if (chunks.Length != 0)
                    {
                        discount.DiscountCode = chunks[0];
                        discount.DiscountAmount = Int32.Parse(chunks[1]);
                       


                    }


                }

                );
                Book_SechduleFlightContext db = new Book_SechduleFlightContext();
                db.Add(discount);
                db.SaveChanges();
                Console.WriteLine(message);
            };

            channel.BasicConsume("AddDiscountQueue", true, consumer);
            Console.WriteLine("Consumer started");
            Console.ReadLine();
        }
        public void Deregister()
        {
            this.connection.Close();

        }

        public AddDiscountQueueConsumer()
        {
            this.factory = new ConnectionFactory()
            {
                Uri = new Uri("amqp://guest:guest@localhost:5672")
            };

            this.connection = factory.CreateConnection();
            this.channel = connection.CreateModel();
        }

    }
}
