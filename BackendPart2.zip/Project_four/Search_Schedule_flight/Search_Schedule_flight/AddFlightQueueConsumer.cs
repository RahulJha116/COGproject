﻿using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Search_Schedule_flight.DbContexts;
using Search_Schedule_flight.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Search_Schedule_flight
{
    public class AddFlightQueueConsumer
    {
        ConnectionFactory factory { get; set; }
        IConnection connection { get; set; }
        IModel channel { get; set; }
        public void Consume()
        {

            channel.QueueDeclare("AddFlightQueue",
                durable: true,
                exclusive: false,
                autoDelete: false,
                arguments: null);

            var consumer = new EventingBasicConsumer(channel);

            consumer.Received += (Sender, e) =>
            {

                var body = e.Body.ToArray();
                var message = Encoding.UTF8.GetString(body);

                var Flight = new Flights();
                Task.Run(() =>
                {
                    var chunks = message.Split("|");
                    if (chunks.Length != 0)
                    {
                        Flight.FromPlace = chunks[0];
                        Flight.ToPlace = chunks[1];
                        Flight.StartDateTime = DateTime.Parse(chunks[2]);
                        Flight.EndDateTime = DateTime.Parse(chunks[3]);
                        Flight.FlightNumber = chunks[4];
                        Flight.ScheduleDayOfWeek = chunks[5];
                        Flight.NoOfBusinessClassSeat = Int32.Parse(chunks[6]);
                        Flight.NoOfNonBusinessClassSeat = Int32.Parse(chunks[7]);
                        Flight.LeftBuisnessClassSeat = Int32.Parse(chunks[6]);
                        Flight.LeftNonBuisnessClassSeat = Int32.Parse(chunks[7]);
                        Flight.FlightBusinessClassTicketPrice = Int32.Parse(chunks[8]);
                        Flight.FlightNonBusinessClassTicketPrice = Int32.Parse(chunks[9]);
                        Flight.Indicator = Int32.Parse(chunks[10]);
                        Flight.airlineId = Int32.Parse(chunks[11]);
                        Flight.Meal = chunks[12];


                    }


                }

                );
                Book_SechduleFlightContext db = new Book_SechduleFlightContext();
                db.Add(Flight);
                db.SaveChanges();
                Console.WriteLine(message);
            };

            channel.BasicConsume("AddFlightQueue", true, consumer);
            Console.WriteLine("Consumer started");
            Console.ReadLine();
        }
        public void Deregister()
        {
            this.connection.Close();

        }

        public AddFlightQueueConsumer()
        {
            this.factory = new ConnectionFactory()
            {
                Uri = new Uri("amqp://guest:guest@localhost:5672")
            };

            this.connection = factory.CreateConnection();
            this.channel = connection.CreateModel();
        }

    }
}
