export class AdminUser {
    adminEmailId:string;
    adminPasskey:string;
    token:string;

    constructor(){
        this.adminEmailId="";
        this.adminPasskey="";
        this.token="";

    }

}