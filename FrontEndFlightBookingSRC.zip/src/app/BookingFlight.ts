export class BookingFlight {
    flightNumber :string;
    passengerDetail:string;
    meal:string
    businessClass  :boolean;
    numberOfSeats  :number;
    seatNumbers  :number;
    priceOfTicket  :number;
    userEmailId :string;
    StartDateTime:Date;
    EndDateTime:Date;
    FromPlace:string;
    ToPlace:string;
    DiscountCode:string;


    constructor(){
        this.flightNumber="";
        this.passengerDetail=""
        this.meal=""
        this.businessClass=false;
        this.numberOfSeats=0;
        this.seatNumbers=0;
        this.priceOfTicket=0;
        this.userEmailId="";
        this.StartDateTime= new Date('dd/M/yyyy hh:mm:ss');
        this.EndDateTime=new Date('dd/M/yyyy hh:mm:ss');
        this.FromPlace="";
        this.ToPlace="";
        this.DiscountCode="";





    }

}