export class Email {
    UserEmailId : string;
    

    constructor(){
        this.UserEmailId="";
    }
}