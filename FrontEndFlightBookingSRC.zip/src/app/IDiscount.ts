export interface IDiscount {
    discountId:number;
    discountCode:string;
    discountAmount:number;
}