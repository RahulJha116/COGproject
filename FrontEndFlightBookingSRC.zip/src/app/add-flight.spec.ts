import { AddFlight } from './add-flight';

describe('AddFlight', () => {
  it('should create an instance', () => {
    expect(new AddFlight()).toBeTruthy();
  });
});
