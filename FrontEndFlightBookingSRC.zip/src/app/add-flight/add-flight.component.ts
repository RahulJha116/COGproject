import { Component, OnInit } from '@angular/core';

import { AdminLoginService } from '../adminlogin.service';    
import { AddFlight } from '../add-flight';  
import { Router } from '@angular/router';    
import {Observable} from 'rxjs';    
import { NgForm, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms'; 

@Component({
  selector: 'app-add-flight',
  templateUrl: './add-flight.component.html',
  styleUrls: ['./add-flight.component.css']
})
export class AddFlightComponent implements OnInit {

  data = false;    
  submitted = false;
  AddFlightForm: any;    
  massage:string;    
  constructor(private formbulider: FormBuilder,private loginService:AdminLoginService,private router:Router) {
    this.massage = "";
   }    
    
  ngOnInit() {    
    this.AddFlightForm = this.formbulider.group({    
      FromPlace: ['', [Validators.required]],    
      ToPlace: ['', [Validators.required]],  
      StartDateTime:  ['', [Validators.required]], 
      EndDateTime:['', [Validators.required]], 
      FlightNumber: ['', [Validators.required,  Validators.maxLength(8)]],         
      ScheduleDayOfWeek: ['', [Validators.required]], 
      NoOfBusinessClassSeat:['', [Validators.required]], 
      NoOfNonBusinessClassSeat:['', [Validators.required]], 
      FlightBusinessClassTicketPrice:['', [Validators.required]], 
      FlightNonBusinessClassTicketPrice:['', [Validators.required]], 
      Meal:['', [Validators.required]], 
      airlineId:['', [Validators.required]], 

    });    
  }    

  get f() {return this.AddFlightForm.controls;}
   onFormSubmit()    
  {    
    this.submitted=true;

    const flight = this.AddFlightForm.value;    
    this.AddFlight(flight);    
  }    
  onreset(){
    
    this.AddFlightForm.reset();}

  AddFlight(flight:AddFlight)    
  {    
  this.loginService.AddFlight(flight).subscribe(    
    ()=>    
    {    
      this.data = true;
      console.log("Flight Added !!!")
     
      this.router.navigate(['/AdminDashboard']);   
      this.AddFlightForm.reset();    
    });    
  }    
}  

