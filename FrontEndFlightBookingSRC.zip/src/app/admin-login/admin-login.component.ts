import { Component, OnInit } from '@angular/core';    
import { Router, ActivatedRoute } from '@angular/router';    
import { AdminLoginService } from '../adminlogin.service';   

import { first } from 'rxjs/operators'; 
import { FormsModule, FormBuilder, Validators } from '@angular/forms'; 

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent{

  loginForm: any;
  submitClick = false;
  submitted = false;
  returnUrl: string;
  error = '';
  data:any;
   constructor(private formBuilder: FormBuilder,private router:Router,private LoginService:AdminLoginService, private route: ActivatedRoute) {
     this.returnUrl = "";
     if(this.LoginService.currentUserValue){
       this.router.navigate(['/']);
     }
    }    
     
     
    ngOnInit() {
     this.loginForm = this.formBuilder.group({
     EmailId: ['', Validators.required],
     password: ['', Validators.required]
    });
    
     
     this.LoginService.logout();
    
     
     this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
     }
    
     // convenience getter for easy access to form fields
     get formData() { return this.loginForm.controls; }
    
     onLogin() {
     this.submitted = true;
    
     // stop here if form is invalid
     if (this.loginForm.invalid) {
     return;
     }
    
     this.submitClick = true;
     this.LoginService.Login(this.formData.EmailId.value, this.formData.password.value)
     .subscribe(z=>{
       console.log(z);
       localStorage.setItem('token',z.toString());

       if(z!=null)
       {
         alert("logged in sucessfully")
       this.router.navigate(['/AdminDashboard']);  
       }
      //  if(z!=null)
      //  {
      //    this.router.navigate("/AdminDashBoard");
      //  }

       


     }
     )
     
     
    
     }
    }
  
       
