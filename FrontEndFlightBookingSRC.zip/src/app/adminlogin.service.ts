import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';  
import {HttpHeaders} from '@angular/common/http';  
import { HttpErrorResponse} from '@angular/common/http';
import {  BehaviorSubject, from, Observable, observable, throwError } from 'rxjs'; 
import { map, catchError,tap } from 'rxjs/operators'; 
import { Airline } from './airline';
import { AddFlight } from './add-flight';
import { Router } from '@angular/router';  
import { Discount } from './Discount';
import { IDiscount } from './IDiscount';

@Injectable({
  providedIn: 'root'
})
export class AdminLoginService {  
  //token : string;  
  Url: any;
  header : any;  
  constructor(private http : HttpClient, private Router:Router) {   
  

    this.Url = 'http://localhost:59349/';  
  }
  
  Login(EmailId: string, Passkey: string){  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
    return this.http.post(this.Url+'Airline/Adminlogin?'+'adminEmailId='+EmailId + '&adminPasskey='+Passkey,httpOptions);
    

    
    
  }  

  logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('currentUser');
  }

  GetAllDiscountbyid(discountid:number):Observable<any>
  {
   const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
   return this.http.get(this.Url + 'Discount/'+discountid,  httpOptions)
  }
  AddDiscount(discount:Discount)  
   {  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
    return this.http.post<Discount>(this.Url + 'Discount/AddDiscount', discount, httpOptions)  
   } 
  DeleteDiscount(discountId:number)
  {
   const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
   return this.http.delete(this.Url + 'Discount/DeleteDiscount?id=' + discountId,  httpOptions)
  }
  updateDiscount(discount:IDiscount)
 {
   const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
   return this.http.put<string>(this.Url + 'Discount/updateDiscount', discount, httpOptions) 
 }
 GetAllDiscount()
 {
  const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
  return this.http.get(this.Url + 'Discount',  httpOptions)

 }
 BlockAirline(airlineId:number)
 {
  const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) }; 
  return this.http.post(this.Url + 'Flight/BlockFlight?airlineid=' + airlineId,  httpOptions)

 }
 UnBlockAirline(airlineId:number)
 {
  const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) }; 
  return this.http.post(this.Url + 'Flight/UnBlockFlight?airlineid=' + airlineId,  httpOptions)

 }
 GetAllAirline()
 {
  const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
  return this.http.get(this.Url + 'Airline',  httpOptions)
 }
 ViewRelatedFlights(airlineId:number)
 {
   
  const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) }; 
  return this.http.get(this.Url + 'Flight/GetFlightByAirlineId?airlineid=' + airlineId,  httpOptions)
 }
 AddAirline(airline:Airline)  
    
    {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
    return this.http.post<Airline>(this.Url + 'Airline/register', airline, httpOptions)  
   }  
   AddFlight(flight:AddFlight)  
   {  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
    return this.http.post<AddFlight>(this.Url + 'Flight/Add', flight, httpOptions)  
   } 
}

