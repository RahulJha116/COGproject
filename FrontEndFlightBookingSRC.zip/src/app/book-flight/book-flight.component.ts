import { Component, OnInit } from '@angular/core';
import { IFlightLinked } from '../IFlightLiked';
import { LoginService } from '../login.service'; 
import { AdminLoginService } from '../adminlogin.service';   

import { BookingFlight } from 'src/BookingFlight';
import { Router, ActivatedRoute } from '@angular/router';    
import {Observable} from 'rxjs';    
import { IDiscount } from '../IDiscount';
import { NgForm, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms'; 
@Component({
  selector: 'app-book-flight',
  templateUrl: './book-flight.component.html',
  styleUrls: ['./book-flight.component.css']
})
export class BookFlightComponent implements OnInit {
 flightdata :IFlightLinked[]=[];
 discountdata:any=[];
 iterableLogList:any;  
  submitted = false;
  BookForm: any;    
  massage:any;    
  constructor(private route:ActivatedRoute,private formbulider: FormBuilder,private loginService:LoginService,private admin:AdminLoginService,private router:Router) {
    this.massage = "";
   }    
    
  ngOnInit() {    
    this.route.params.subscribe(params =>{
      let flightId = params["id"];
      console.log(flightId);

        this.loginService.GetFlightById(flightId).toPromise().then(res=>{
          this.BookForm = this.formbulider.group({    
            flightNumber: [res.flightNumber, [Validators.required]],    
            passengerDetail: ['', [Validators.required]],  
            meal:  ['', [Validators.required]], 
            businessClass:[false, [Validators.required]], 
            numberOfSeats: ['', [Validators.required]],         
            seatNumbers: ['', [Validators.required]], 
            priceOfTicket:[res.flightNonBusinessClassTicketPrice, [Validators.required]], 
            userEmailId:['', [Validators.required]],
            StartDateTime  : [res.startDateTime, [Validators.required]],
            EndDateTime  : [res.endDateTime, [Validators.required]],    
            FromPlace : [res.fromPlace, [Validators.required]],
            ToPlace  : [res.toPlace, [Validators.required]],
            DiscountCode: ['', [Validators.required]],
          });
        })})

      
  }    
  

  get f() {return this.BookForm.controls;}

  onFormSubmit()    
  {    
    this.submitted=true;

    const flight = this.BookForm.value;    
    this.BookFlight(flight);    
  }    
  onreset(){
    
    this.BookForm.reset();}


  BookFlight(bookingFlight:BookingFlight)    
  {    
  this.loginService.BookFlight(bookingFlight).subscribe(    
    (data=>    
    {    
      
      this.massage = data;
      console.log(this.massage);
      
      alert("Flight Booked !!!" + this.massage)
     
      this.router.navigate(['/Dashboard']);   
      this.BookForm.reset();  

      
      
        
    })  ) 
  }    
  showDiscount()
  {
    this.admin.GetAllDiscount().subscribe(data =>
      {
      this.discountdata=data;
      console.log(this.discountdata)

    })
  }
 
}  
