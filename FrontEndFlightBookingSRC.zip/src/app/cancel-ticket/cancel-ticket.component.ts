import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-cancel-ticket',
  templateUrl: './cancel-ticket.component.html',
  styleUrls: ['./cancel-ticket.component.css']
})
export class CancelTicketComponent implements OnInit {

  UserForm:any;
  a:any;
  
  submitted = false;
  constructor(private formbulider: FormBuilder,private loginService:LoginService,
    private router:Router) { }

  ngOnInit()  {this.UserForm = this.formbulider.group({    
    PNR: ['', [Validators.required]],
   

  });  
  }

  get f() {return this.UserForm.controls;}

  onSubmit(){

    const pnr = this.UserForm.value; 
    console.log(pnr)   
    this.ticketCancel(pnr); 
  }

  onreset(){
    this.UserForm.reset();
  }

  

  ticketCancel(pnr:string){
    console.log(pnr)
    this.loginService.TicketCancel(pnr).subscribe(
      data=>{
        this.a=data

        //alert("ticket Cancelled")
        this.router.navigate(['/Dashboard'])


        
      }  )


  }

}
