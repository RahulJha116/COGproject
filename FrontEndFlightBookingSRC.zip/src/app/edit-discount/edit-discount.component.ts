import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminLoginService } from '../adminlogin.service';
import { IDiscount } from '../IDiscount';
import { observable } from 'rxjs';

import {Observable} from 'rxjs';    
import { NgForm, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms'; 
import { Discount } from '../Discount';

@Component({
  selector: 'app-edit-discount',
  templateUrl: './edit-discount.component.html',
  styleUrls: ['./edit-discount.component.css']
})
export class EditDiscountComponent implements OnInit {
  data = false; 

  AddDiscountForm:any;
  submitted:any;
  iterableLogList:any;
  discountdata : IDiscount[] = [];
  constructor(private route:ActivatedRoute,private router:Router,private  formbuilder:FormBuilder, private loginService:AdminLoginService, private activatedRoute:ActivatedRoute) 
  { }

  
  ngOnInit(): void {
    this.route.params.subscribe(params =>{
      let discountid = params["id"];
      console.log(discountid);
      this.loginService.GetAllDiscountbyid(discountid).toPromise().then(res=>{
        this.AddDiscountForm = this.formbuilder.group({
          DiscountId:[res.discountId, [Validators.required]],
          DiscountCode: [res.discountCode, [Validators.required]],    
          DiscountAmount: [res.discountAmount, [Validators.required]],  
        });
      })})
  }

  get f() {return this.AddDiscountForm.controls;}
   onFormSubmit()    
  {    
    this.submitted=true;


    const flight = this.AddDiscountForm.value;    
    this.UpdateDiscount(flight);    
  }    
  onreset(){
    
    this.AddDiscountForm.reset();}

  UpdateDiscount(discount:IDiscount)   
  {    
  this.loginService.updateDiscount(discount).subscribe()
    {
      this.data=true;
      alert("Discount updated !!!")
      this.router.navigate(['/viewdiscount']); 

      
    }  
  }
  
  

  

  
}
