import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AdminLoginService } from './adminlogin.service';

@Injectable()
export class jwtInterceptor implements HttpInterceptor {
    constructor(private loginService:AdminLoginService){}
 intercept(request: HttpRequest<any>, newRequest: HttpHandler): Observable<HttpEvent<any>> {
 
    let currentUser=this.loginService.currentUserValue;

 
 

 if (currentUser && currentUser.token) {
 request = request.clone({
 setHeaders: {
 Authorization: `Bearer ${currentUser.token}`,
 'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
 }
 });
 }

 return newRequest.handle(request);
 }
}