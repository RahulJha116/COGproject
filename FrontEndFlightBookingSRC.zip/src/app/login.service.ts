import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';  
import {HttpHeaders} from '@angular/common/http';  
import { Register } from './register';
import { from, Observable } from 'rxjs';  
import { PNR } from 'src/PNR';
import { map } from 'rxjs/operators';
import { SearchFlightOneway } from './search-flight-oneway';
import { oneway } from './oneway';
import { Email } from './Email';
import { BookingFlight } from 'src/BookingFlight';

@Injectable({
  providedIn: 'root'
})
export class LoginService {  
  Url :string;  
  //token : string;  
  header : any;  
  constructor(private http : HttpClient) {   
  
    this.Url = 'http://localhost:59349/';  
  
    const headerSettings: {[name: string]: string | string[]; } = {};  
    this.header = new HttpHeaders(headerSettings);  
  }  

  Login(EmailId: string, Passkey: string){  
      
   
   const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
   return this.http.post(this.Url+'User/UserLogin?'+'EmailId='+EmailId + '&PassKey='+Passkey,httpOptions);
   


  }
  
  
  logout() {
    localStorage.removeItem('TokenInfo');
  }
   
  
  
  CreateUser(register:Register)  
  {  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
    return this.http.post<Register>(this.Url + 'User/register', register, httpOptions)  
  }  
  SearchFlightOneWay(searchFlightOneWay:SearchFlightOneway):Observable<any> 
  { 
   const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
   return this.http.get(this.Url + 'BookandSearch/SearchOneWay?'+'fromPlace=' +searchFlightOneWay.fromPlace
   +'&toPlace='+searchFlightOneWay.toPlace+'&flightDate='+ searchFlightOneWay.flightDate);
   
  }
  Searchpnr(pnr:PNR): Observable<any>
  {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
    return this.http.get(this.Url + 'BookandSearch/SearchPNR?' + 'PNR=' + pnr.PNR);
  }
  SearchBookingHistory(email:Email): Observable<any>
  {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
    return this.http.get(this.Url + 'BookandSearch/GetBookingHistory?' + 'EmailId=' + email.UserEmailId);
  }
  GetFlightById(id:number):Observable<any>
  {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
    return this.http.get(this.Url + 'BookandSearch/'+id);
  }
  BookFlight(bookingFlight:BookingFlight)
  {
    {  
      const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
      return this.http.post(this.Url + 'BookandSearch/BookFlight', bookingFlight, {responseType: 'text'})  
    }  
  }
  TicketCancel(a:string)
  { 
   // console.log(pnr)
  // let jwttoken=localStorage.getItem('usertoken');
  //console.log(jwttoken)
   // let header = new HttpHeaders().set("Content-Type", "application/json").set("Authorization","Bearer " +jwttoken);
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
    return this.http.delete(this.Url + 'BookandSearch/TicketCancel?PNR=' + a,httpOptions);//{headers:header, responseType: 'text'});
  }
  

}

