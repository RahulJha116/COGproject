export class Register {  
    UserName:string;
    EmailId:string; 
    Age:number;
    Address:string    
    Passkey:string;  
     
     

    constructor(){
        this.UserName="";
        this.EmailId="";
        this.Age=0;
        this.Address="";
        this.Passkey="";
        
    }
}  
