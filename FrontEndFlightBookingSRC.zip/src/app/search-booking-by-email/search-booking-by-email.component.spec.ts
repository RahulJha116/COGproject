import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchBookingByEmailComponent } from './search-booking-by-email.component';

describe('SearchBookingByEmailComponent', () => {
  let component: SearchBookingByEmailComponent;
  let fixture: ComponentFixture<SearchBookingByEmailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchBookingByEmailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchBookingByEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
