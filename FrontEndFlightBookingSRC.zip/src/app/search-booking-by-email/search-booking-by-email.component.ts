import { Component, OnInit } from '@angular/core';

import { IBooking } from '../IBooking';
import { LoginService } from '../login.service';    
import { Router } from '@angular/router';    
import {Observable} from 'rxjs';    
import { NgForm, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms'; 
import { Email } from '../Email';

@Component({
  selector: 'app-search-booking-by-email',
  templateUrl: './search-booking-by-email.component.html',
  styleUrls: ['./search-booking-by-email.component.css']
})
export class SearchBookingByEmailComponent implements OnInit {

  data = false;    
  submitted = false;
  SearchEmailForm: any;    
  
  BookingData: IBooking[] = [];
  massage:string; 
  constructor(private formbulider: FormBuilder,private loginService:LoginService,
    private router:Router) {
    this.massage = "";
   };
    
  ngOnInit() {    
    this.SearchEmailForm = this.formbulider.group({    
      UserEmailId: ['', [Validators.required]],
     

    });  
    
  }    

  get f() {return this.SearchEmailForm.controls;}
   onFormSubmit()    
  {    
    this.submitted=true;

    const email = this.SearchEmailForm.value;    
    this.SearchPNRMethod(email);    
  }    
  onreset(){
    
    this.SearchEmailForm.reset();}

  SearchPNRMethod(email:Email)   
  {    
  this.loginService.SearchBookingHistory(email).subscribe(
    data=>{
      this.BookingData=data;
      console.log(this.BookingData)
    }  
       
  )}
}  
