import { SearchFlightOneway } from './search-flight-oneway';

describe('SearchFlightOneway', () => {
  it('should create an instance', () => {
    expect(new SearchFlightOneway()).toBeTruthy();
  });
});
