export class SearchFlightOneway {
    fromPlace : string;
    toPlace  :string;
    flightDate  :Date; 

    constructor(){
        this.fromPlace="";
        this.toPlace="";
        this.flightDate=new Date('dd/M/yyyy hh:mm:ss');
    }
}
