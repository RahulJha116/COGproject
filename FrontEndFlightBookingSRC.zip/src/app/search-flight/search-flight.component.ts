import { Component, OnInit ,Input} from '@angular/core';
import { Inject, Injectable } from '@angular/core';
import { LoginService } from '../login.service';    
import {SearchFlightOneway} from '../search-flight-oneway';    
import { Router } from '@angular/router';    
import {Observable} from 'rxjs';    
import { NgForm, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms'; 
import { oneway } from '../oneway';
import { IBooking } from '../IBooking';


@Component({
  selector: 'app-search-flight',
  templateUrl: './search-flight.component.html',
  styleUrls: ['./search-flight.component.css']
})

export class SearchFlightComponent implements OnInit {

  data = false;    
  submitted = false;
  SearchFlightForm: any;    
  
  sliderValue: number = 0;
  bookingdata: IBooking[] = [];
  onewaydata: oneway[] = [];
  massage:string; 
  constructor(private formbulider: FormBuilder,private loginService:LoginService,
    private router:Router) {
    this.massage = "";
   };
    
  ngOnInit() {    
    this.SearchFlightForm = this.formbulider.group({    
      fromPlace: ['', [Validators.required]],    
      toPlace: ['', [Validators.required]],  
      flightDate:  ['', [Validators.required]], 
     

    });  
    
  }    

  get f() {return this.SearchFlightForm.controls;}
   onFormSubmit()    
  {    
    this.submitted=true;

    const flight = this.SearchFlightForm.value;    
    this.SearchFlightOneWayMethod(flight);    
  }    
  onreset(){
    
    this.SearchFlightForm.reset();}

  SearchFlightOneWayMethod(searchFlightOneWay:SearchFlightOneway)   
  {    
  this.loginService.SearchFlightOneWay(searchFlightOneWay).subscribe(
    data=>{
      this.onewaydata=data;
      console.log(this.onewaydata)
    }  
       
  )}
  BookFlight(flightId:number){

    this.router.navigate(["booked", flightId]);
    
  }
}  