import { Component, OnInit } from '@angular/core';
import { IBooking } from '../IBooking';
import { LoginService } from '../login.service';    
import { Router } from '@angular/router';    
import {Observable} from 'rxjs';    
import { NgForm, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms'; 
import { PNR } from 'src/PNR';

@Component({
  selector: 'app-search-pnr',
  templateUrl: './search-pnr.component.html',
  styleUrls: ['./search-pnr.component.css']
})
export class SearchPNRComponent implements OnInit {

  data = false;    
  submitted = false;
  SearchPNRForm: any;    
  
  BookingData: IBooking[] = [];
  massage:string; 
  constructor(private formbulider: FormBuilder,private loginService:LoginService,
    private router:Router) {
    this.massage = "";
   };
    
  ngOnInit() {    
    this.SearchPNRForm = this.formbulider.group({    
      PNR: ['', [Validators.required]],
     

    });  
    
  }    

  get f() {return this.SearchPNRForm.controls;}
   onFormSubmit()    
  {    
    this.submitted=true;

    const pnr = this.SearchPNRForm.value;    
    this.SearchPNRMethod(pnr);    
  }    
  onreset(){
    
    this.SearchPNRForm.reset();}

  SearchPNRMethod(pnr:PNR)   
  {    
  this.loginService.Searchpnr(pnr).subscribe(
    data=>{
      this.BookingData=data;
      console.log(this.BookingData)
    }  
       
  )}
}  
