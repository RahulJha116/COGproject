import { Component, OnInit } from '@angular/core';    
import { Router ,ActivatedRoute} from '@angular/router';    
import { LoginService } from '../login.service';    
import { FormsModule, FormBuilder, Validators } from '@angular/forms'; 

import { first } from 'rxjs/operators'; 

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent{

 loginForm: any;
 submitClick = false;
 submitted = false;
 returnUrl: string;
 error = '';
 
  constructor(private formBuilder: FormBuilder,private router:Router,private LoginService:LoginService, private route: ActivatedRoute) {
    this.returnUrl = "";
   }    
    
    
   ngOnInit() {
    this.loginForm = this.formBuilder.group({
    EmailId: ['', Validators.required],
    password: ['', Validators.required]
    });
   
    this.LoginService.logout();
   
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    }
   
    get formData() { return this.loginForm.controls; }
   
    onLogin() {
    this.submitted = true;
   
    if (this.loginForm.invalid) {
    return;
    }
   
    this.submitClick = true;
    this.LoginService.Login(this.formData.EmailId.value, this.formData.password.value)
    .subscribe(z=>{
      console.log(z);
      localStorage.setItem('usertoken',z.toString());

      if(z!=null)
      {
        alert("logged in sucessfully")
      this.router.navigate(['/Dashboard']);  
      }})


    
    }
   }
      
