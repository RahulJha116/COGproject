import { Component, OnInit } from '@angular/core';
import { AdminLoginService } from '../adminlogin.service';
import { IViewairline } from '../IViewairline';
import { IFlightLinked } from '../IFlightLiked';

@Component({
  selector: 'app-view-airline',
  templateUrl: './view-airline.component.html',
  styleUrls: ['./view-airline.component.css']
})
export class ViewAirlineComponent implements OnInit {

  AirlineData : IViewairline[] = [];
  FlightData : IFlightLinked[]=[];
  constructor(private LoginService:AdminLoginService) { }

  ngOnInit() {
    this.LoginService.GetAllAirline().subscribe((data:any) =>
    {
      this.AirlineData=data;
      

    });
  }
  onEdit(airlineId:number){
    console.log('willEdited')
  }
  onBlock(airlineId:number){
    this.LoginService.BlockAirline(airlineId).subscribe();
    console.log('All flight linked to this airline id is blocked, User no longer able to see this in search Flight menu')
  }
  onUnBlock(airlineId:number){
    this.LoginService.UnBlockAirline(airlineId).subscribe();
    console.log('All flight linked to this airline id is Un-blocked, User will able to see related flights in search Flight menu')
  }
  onViewRelatedFlights(airlineId:number){
    this.LoginService.ViewRelatedFlights(airlineId).subscribe((data:any)=>
    {
      this.FlightData=data;

    });
    console.log("Linked Flights")

  }
  


}
