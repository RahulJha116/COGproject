import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AdminLoginService } from '../adminlogin.service';
import { IDiscount } from '../IDiscount';

@Component({
  selector: 'app-view-discount',
  templateUrl: './view-discount.component.html',
  styleUrls: ['./view-discount.component.css']
})
export class ViewDiscountComponent implements OnInit {

  
  discountData : IDiscount[]=[];
  constructor(private LoginService:AdminLoginService, private router:Router) { }

  ngOnInit() {
    this.LoginService.GetAllDiscount().subscribe((data:any) =>
    {
      this.discountData=data;

      

    });
    
  }
  
  onEdit(discountId:number){
    this.router.navigate(["editDiscount", discountId])
  }
  onBlock(discountId:number){
   this.LoginService.DeleteDiscount(discountId).subscribe(()=>
   
    
  
    console.log('Discount Deleted')
  )};
  
}
